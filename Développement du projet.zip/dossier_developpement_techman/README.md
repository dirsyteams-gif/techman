# Dossier de développement — TechMan
### Outil de suivi Diagnostic, Calibration, Maintenance et Réparation des détecteurs de gaz et d'alcoolémie

Version 1.0 · 28 juillet 2026 · Destinataire : équipe de développement (utilisable directement avec Claude Code)

---

## 1. Vue d'ensemble

TechMan est un outil **100 % hors ligne** destiné à un représentant de marque de détecteurs de gaz et d'alcoolémie. Il permet au **gestionnaire de stock** et aux **techniciens** de suivre chaque équipement reçu sur tout son cycle : réception → diagnostic → calibration → réparation → restitution, avec génération de rapports d'intervention et export des données.

Contenu du dossier :

| Fichier | Rôle |
| --- | --- |
| `README.md` | Ce document — spécification d'implémentation complète |
| `Cahier_des_charges_Outil_Suivi_Detecteurs.docx` | Cahier des charges fonctionnel d'origine (V1.0) |
| `design/Prototype TechMan.dc.html` | **Prototype interactif de référence** (8 écrans) — ouvrir dans un navigateur |
| `design/Deck.dc.html` | Présentation de cadrage (22 diapos) validée avec le client |
| `design/_ds/…/styles.css` | Design system « Industry » : tokens et composants CSS |
| autres `design/*.js` | Runtime nécessaire à l'ouverture des fichiers de design |

## 2. Nature des fichiers de design

Les fichiers du dossier `design/` sont des **références de design réalisées en HTML** : des prototypes montrant l'apparence et le comportement attendus, **pas du code de production à copier tel quel**. La tâche consiste à **recréer ces écrans dans l'environnement cible** avec ses patterns et bibliothèques. Aucun environnement n'existe encore : choisir une stack adaptée à la contrainte hors ligne (voir §4).

**Fidélité : haute (hi-fi).** Couleurs, typographie, espacements, libellés et interactions du prototype sont contractuels — les recréer fidèlement. Le CSS du design system (`design/_ds/…/styles.css`) contient les valeurs exactes (variables `--color-*`, `--font-*`, `--space-*`).

## 3. Écarts validés par rapport au cahier des charges

Le prototype intègre des décisions postérieures au document Word — **le prototype fait foi** :

1. **Réception sans checklist, multi-unités** : le gestionnaire enregistre plusieurs appareils du même modèle pour le même client dans un seul formulaire (une ligne par unité : identifiant unique pré-rempli, n° série, courte observation). La checklist n'est PAS saisie à la réception.
2. **Checklist de diagnostic** : les 11 items (Annexe B du cahier des charges) sont remplis par le technicien sur la fiche équipement, puis **validés définitivement** (non modifiable ensuite ; corrections = notes horodatées).
3. **Statuts étendus** : Reçu → Diagnostiqué → Calibration en cours / effectuée → Réparation en cours / effectuée → Terminé → Restitué au client. Le passage « en cours » est automatique à l'ouverture de l'écran de calibration/réparation.
4. **Tableau de bord piloté** : 5 KPIs (réceptionnés, diagnostiqués, calibrés, réparés, livrés — avec les « en cours »), filtres par client / produit / mois / semaine / intervalle de jours, bouton « Tirer un bilan » (document imprimable) et **export Excel** (CSV `;` UTF-8 BOM, 20 colonnes, périmètre filtré).
5. **Checklist de calibration générique** commune à tous les modèles (V1) ; **pas de seuil batterie** générant d'anomalie automatique en V1 (prévoir le paramètre, désactivé par défaut) ; interface **bilingue FR/EN** (libellés de checklist en anglais).

Points restant ouverts avec le client : format définitif de l'identifiant unique ; export Word en plus du PDF.

## 4. Contraintes techniques (non fonctionnelles)

- **Hors ligne intégral** : aucune saisie ne dépend du réseau. Base de données locale embarquée (ex. SQLite via Electron/Tauri, ou PWA + IndexedDB). L'architecture ne doit pas rendre impossible une future synchronisation multi-postes avec gestion de conflits (hors périmètre V1, à anticiper).
- **Authentification locale** : nom + mot de passe, deux profils (gestionnaire de stock, technicien). Un technicien ne peut ni administrer le catalogue ni supprimer un client.
- **Traçabilité** : chaque saisie conserve utilisateur + date/heure. Checklist validée = figée.
- **Exports locaux** : rapports PDF imprimables hors ligne ; données en CSV/Excel.

## 5. Modèle de données

- **Client** : nom (obligatoire, clé), contact, adresse.
- **Modèle (catalogue)** : nom unique, type Mobile/Fixe, actif (booléen). 23 modèles initiaux (Annexe A du cahier des charges ; liste seedée dans le prototype, `state.models`). Un modèle utilisé ne se supprime pas — il se désactive.
- **Équipement** : identifiant unique (saisi, convention `[MODÈLE ABRÉGÉ]-[JJMMAA]-[NN]`, anti-doublon local), client, modèle, n° série constructeur, date de réception, reçu par, statut, commentaire de réception (`obs`), checklist (9 booléens + Battery % numérique + Initial Remarks texte), `checklistDone`.
- **Interventions** rattachées à l'équipement : notes de diagnostic, calibrations (éléments vérifiés, gaz étalon, valeurs avant/après, résultat conforme/non, remarques), réparations (pièces changées, description, remarques) — toutes horodatées et attribuées.
- **Rapports** : documents générés (jamais saisis) — par équipement ou groupés par client (page de garde : total, répartition par statut, total anomalies).

**Règle d'anomalie** : tout item de checklist non coché = anomalie, reportée automatiquement dans le rapport. Items : Serial Num, Front Cover, Back Cover, Sensor Filter, Screen, Buttons, Carrying Clip, Alarm, Sensor(s) (+ Battery % en relevé, + Initial Remarks en texte libre).

## 6. Écrans (8) — se référer au prototype

1. **Connexion** — carte centrée « blueprint », champs nom/mot de passe, deux boutons de profil.
2. **Tableau de bord** — rangée de 5 KPIs (cartes blueprint, chiffre 40px Barlow Condensed accent-700), panneau de filtres (client, produit, période : tout/mois/semaine/intervalle), compteurs par statut (tags cliquables), table des équipements, bouton « Tirer un bilan » et « ⤓ Exporter Excel ».
3. **Réception** — colonne gauche : client, modèle, date, reçu par ; colonne droite : tableau des unités (#, identifiant pré-rempli, n° série, observation, retrait), « + Ajouter une unité », validation anti-doublon par ligne, création d'une fiche par unité au statut « Reçu ».
4. **Fiche équipement** — en-tête (identifiant, tag statut, méta, commentaire de réception) ; checklist de diagnostic éditable tant que non validée, puis lecture seule (✓/✗, anomalies en accent-800) ; actions (Calibrer, Réparer, Rapport, sélecteur de statut, note de diagnostic) ; historique des interventions.
5. **Calibration** — 6 éléments vérifiés génériques, gaz étalon, valeurs avant/après, résultat Conforme/Non conforme, remarques ; enregistrement → statut « Calibration effectuée ».
6. **Réparation** — pièces changées en tags sélectionnables (Capot avant/arrière, Filtre, Capteur, Batterie, Écran, Bouton, Clip), description, remarques ; → « Réparation effectuée ».
7. **Rapports** — bascule « Par équipement / Groupé par client », sélecteur, aperçu type document (cadre blueprint, titre condensé, 4 sections numérotées, encadré anomalies), bouton Exporter PDF (impression).
8. **Catalogue & clients** — table des modèles (ajout nom + type, activer/désactiver), cartes clients (ajout) ; lecture seule pour le technicien.

## 7. Design tokens (design system « Industry »)

Source de vérité : `design/_ds/…/styles.css`. L'essentiel :

- **Fond** `--color-bg: #f2f2f3` · **texte** `#1d1f20` · **accent unique** `#5980a6` (rampes 100–900 ; texte accent en `--color-accent-700 #416180`).
- **Typo** : Barlow Condensed 600 (titres) / Barlow (corps). Titres d'écran 34px, titres de carte 20px, corps 14–15px, notes 12–13px.
- **Grammaire visuelle** : angles droits partout, cadres hairline 1px avec **marques d'enregistrement « + » aux 4 coins** (`.blueprint` + `<i class="corner tl/tr/bl/br">`), cartes transparentes (jamais de fond plein) ; le bouton primaire est le seul objet plein (fond accent). Icônes Lucide, trait 1.5.
- **États** : hover/pressed depuis la rampe accent, focus clavier `outline: 2px solid var(--color-accent)`, tags `.tag-accent / .tag-neutral / .tag-outline` pour les statuts.

## 8. Comportements clés à reproduire

- Suggestion d'identifiant : `MODÈLE.toUpperCase().replace(/[^A-Z0-9]/g,'')` (12 car. max) + `-JJMMAA-` + compteur à 2 chiffres par modèle+date ; recalculée au changement de modèle/date ; modifiable ; doublon signalé en direct.
- Filtres du tableau de bord combinés (ET) ; KPIs, compteurs, table, bilan et export Excel calculés sur le même périmètre filtré. Semaine = ISO 8601.
- Export CSV : séparateur `;`, BOM UTF-8, guillemets échappés — colonnes listées dans `exportExcel()` du prototype.
- Rapport groupé : page de garde (nb équipements, terminés/restitués, total anomalies) puis synthèse par appareil.
- Validation de checklist : passe le statut Reçu → Diagnostiqué et fige les données.

## 9. Données de démonstration

Le prototype embarque 3 clients, 23 modèles et 5 équipements d'exemple (`state` de la classe `Component` dans `design/Prototype TechMan.dc.html`) — utilisables comme jeu de seed/tests.

## 10. Assets

Aucune image ni logo : l'identité repose entièrement sur la typographie (Google Fonts Barlow / Barlow Condensed) et les tokens CSS. Le caractère « ⤓ » et « ✓/✗ » sont du texte ; en production, préférer les icônes Lucide équivalentes (download, check, x) en trait 1.5.
